// src/xbase/dbarea.cpp
#include "xbase.hpp"
#include "xindex/index_manager.hpp"  // so unique_ptr<IndexManager> is complete
#include <algorithm>

namespace xbase {

DbArea::~DbArea() = default;

void DbArea::close() {
    if (_fp.is_open()) _fp.close();

    // wipe schema + buffers
    _fields.clear();
    _rawFields.clear();
    _recbuf.clear();
    _fd.clear();
    _fd_snapshot.clear();

    // wipe header & identity
    _hdr = {};                 // zeros num_of_recs, cpr, etc.
    _db_name.clear();
    _filename.clear();

    // reset cursor/deletion flag
    _crn = 0;
    _del = NOT_DELETED;

    // DROP ANY INDEX MANAGER
    _idx.reset();
}

// keep your existing recordLength()/filename()/setFilename() etc.

} // namespace xbase
