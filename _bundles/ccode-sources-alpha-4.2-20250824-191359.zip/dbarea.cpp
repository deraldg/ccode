// src/xbase/dbarea.cpp
#include "xbase.hpp"
#include "xindex/index_manager.hpp"  // for unique_ptr incomplete type

#include <utility>

namespace xbase {

DbArea::DbArea() = default;
DbArea::~DbArea() = default;

// Single, canonical definition for close(). DO NOT define this in dbf_file.cpp.
void DbArea::close() {
    if (_fp.is_open()) {
        _fp.close();
    }
    _filename.clear();
    _db_name.clear();
    _recbuf.clear();
    _fields.clear();
    _rawFields.clear();
    _fd.clear();
    _fd_snapshot.clear();
    _crn = 0;
    _del = NOT_DELETED;
}

// These are referenced by cmd_* and xindex; define them here once.
std::string DbArea::filename() const {
    return _filename.empty() ? _db_name : _filename;
}

void DbArea::setFilename(std::string path) {
    _filename = std::move(path);
}

int DbArea::recordLength() const noexcept {
    return _hdr.cpr;  // same as cpr()
}

} // namespace xbase
