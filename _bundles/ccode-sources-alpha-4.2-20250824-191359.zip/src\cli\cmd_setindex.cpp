// src/cli/cmd_setindex.cpp
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>

#include "xbase.hpp"
#include "xindex/index_manager.hpp"
#include "xindex/dbarea_adapt.hpp"
#include "order_state.hpp"

// forward declare TOP so we can jump to the first record
void cmd_TOP(xbase::DbArea& area, std::istringstream& args);

// ensure_manager() is defined in xindex/attach.cpp
namespace xindex {
    class IndexManager;
    IndexManager& ensure_manager(xbase::DbArea& area);
}

using std::cout;
using std::string;
using std::vector;

void cmd_SETINDEX(xbase::DbArea& area, std::istringstream& args)
{
    string wanted;
    args >> wanted;

    auto& mgr = xindex::ensure_manager(area);

    // No argument: show loaded tags and which one is active.
    if (wanted.empty()) {
        const string active = orderstate::hasOrder(area) ? orderstate::orderName(area)
                                                         : string("(none)");
        const vector<string> tags = mgr.listTags();

        cout << "Index tags loaded: " << tags.size() << "\n";
        for (const auto& tag : tags) {
            const bool isActive = (!active.empty() && active == tag);
            const string expr = mgr.exprFor(tag); // may be empty
            cout << "  " << (isActive ? "* " : "  ") << tag;
            if (!expr.empty()) cout << "  -> " << expr;
            cout << "\n";
        }
        cout << "Active tag: " << active << "\n";
        cout << "Usage: SETINDEX <tag>\n";
        return;
    }

    // Validate the tag exists
    const vector<string> tags = mgr.listTags();
    const bool exists = std::find(tags.begin(), tags.end(), wanted) != tags.end();
    if (!exists) {
        cout << "SETINDEX: no such tag: " << wanted << "\n";
        return;
    }

    // Make it the active order/tag for this area.
    // (If your API differs, adjust this call accordingly.)
    orderstate::setOrder(area, wanted);

    cout << "Index set: " << wanted << " (tag requested: " << wanted << ")\n";

    // Jump to first record under the new order.
    std::istringstream none;
    cmd_TOP(area, none);
}
