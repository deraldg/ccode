#include "xindex/index_manager.hpp"
#include "xindex/index_spec.hpp"
#include "xindex/index_key.hpp"
#include "xindex/index_tag.hpp"
#include "xindex/dbarea_adapt.hpp"

#include <fstream>
#include <sstream>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <unordered_map>

#include "xbase.hpp"
#include "textio.hpp"

using std::string;
using std::vector;

namespace xindex {

static bool ieq(std::string a, std::string b) {
    if (a.size()!=b.size()) return false;
    for (size_t i=0;i<a.size();++i)
        if (std::toupper((unsigned char)a[i]) != std::toupper((unsigned char)b[i])) return false;
    return true;
}

IndexManager::~IndexManager() = default;

std::string IndexManager::trim(std::string s) {
    auto issp = [](unsigned char c){ return std::isspace(c)!=0; };
    while (!s.empty() && issp((unsigned char)s.front())) s.erase(s.begin());
    while (!s.empty() && issp((unsigned char)s.back())) s.pop_back();
    return s;
}
std::string IndexManager::up(std::string s) {
    for (auto& ch : s) ch = static_cast<char>(std::toupper((unsigned char)ch));
    return s;
}

IndexManager::IndexManager(xbase::DbArea& area) : area_(area) {}

bool IndexManager::load_for_table(const std::string& dbfPath) {
    auto p = inx_path(dbfPath);
    (void)p; // reader stubbed; rebuild on demand
    return false;
}

bool IndexManager::save(const std::string& dbfPath) {
    if (!dirty_) return true;
    auto p = inx_path(dbfPath);
    return save_json(p);
}

IndexTag* IndexManager::active() {
    auto it = tags_.find(active_tag_);
    if (it == tags_.end()) return nullptr;
    return it->second.get();
}
const IndexTag* IndexManager::active() const {
    auto it = tags_.find(active_tag_);
    if (it == tags_.end()) return nullptr;
    return it->second.get();
}
bool IndexManager::has_active() const {
    return !active_tag_.empty() && tags_.count(active_tag_)>0;
}

bool IndexManager::set_active(const std::string& tag) {
    auto it = tags_.find(tag);
    if (it == tags_.end()) return false;
    active_tag_    = tag;
    dir_ascending_ = it->second->spec().ascending;
    return true;
}
void IndexManager::clear_active() { active_tag_.clear(); }

void IndexManager::set_direction(bool ascending) { dir_ascending_ = ascending; }

std::string IndexManager::inx_path(const std::string& dbfPath) const {
    auto pos = dbfPath.find_last_of('.');
    if (pos == std::string::npos) return dbfPath + ".inx";
    return dbfPath.substr(0, pos) + ".inx";
}

IndexKey IndexManager::make_key_from_tokens(const IndexSpec& spec, const std::vector<std::string>& toks) const {
    IndexKey k; k.parts.reserve(spec.fields.size());
    for (size_t i=0; i<spec.fields.size(); ++i) {
        std::string v = (i < toks.size() ? trim(toks[i]) : std::string());
        bool isnum = !v.empty() && (std::isdigit((unsigned char)v[0]) || v[0]=='-' || v[0]=='+');
        if (isnum) {
            char* endp=nullptr; double d = std::strtod(v.c_str(), &endp);
            if (endp && *endp=='\0') { k.parts.emplace_back(d); continue; }
        }
        k.parts.emplace_back(up(v));
    }
    return k;
}

IndexKey IndexManager::key_from_record(const IndexSpec& spec, int recno) const {
    IndexKey k; k.parts.reserve(spec.fields.size());
    for (auto const& fname : spec.fields) {
        std::string sv = db_get_string(area_, recno, fname);
        if (!sv.empty()) { k.parts.emplace_back(up(trim(sv))); }
        else { double nv = db_get_double(area_, recno, fname); k.parts.emplace_back(nv); }
    }
    return k;
}

IndexTag& IndexManager::ensure_tag(const IndexSpec& specIn) {
    IndexSpec spec = specIn;
    if (spec.tag.empty()) spec.tag = spec.fields.empty()? std::string("TAG") : spec.fields.front();
    auto it = tags_.find(spec.tag);
    if (it != tags_.end()) {
        // TODO: detect spec drift and rebuild if needed
        return *it->second;
    }
    auto tag = std::make_unique<IndexTag>(spec);
    std::vector<KeyRec> rows;
    int n = db_record_count(area_);
    rows.reserve(n>0?n:0);
    for (int rec=1; rec<=n; ++rec) {
        if (db_is_deleted(area_, rec)) continue;
        IndexKey k = key_from_record(spec, rec);
        rows.push_back(KeyRec{ std::move(k), rec });
    }
    tag->bulk_build(std::move(rows));
    auto& ref = *tag;
    tags_[spec.tag] = std::move(tag);
    dirty_ = true;
    return ref;
}

int IndexManager::top() const {
    auto a = active();
    return a ? (dir_ascending_? a->top() : a->bottom()) : -1;
}
int IndexManager::bottom() const {
    auto a = active();
    return a ? (dir_ascending_? a->bottom() : a->top()) : -1;
}

void IndexManager::on_append(int recno) {
    for (auto& kv : tags_) {
        auto& tag = *kv.second;
        IndexKey k = key_from_record(tag.spec(), recno);
        tag.insert(std::move(k), recno);
    }
    dirty_ = true;
}
void IndexManager::on_replace(int recno) {
    for (auto& kv : tags_) {
        kv.second->erase_recno(recno);
        IndexKey k = key_from_record(kv.second->spec(), recno);
        kv.second->insert(std::move(k), recno);
    }
    dirty_ = true;
}
void IndexManager::on_delete(int recno) {
    for (auto& kv : tags_) kv.second->erase_recno(recno);
    dirty_ = true;
}
void IndexManager::on_recall(int recno) {
    for (auto& kv : tags_) {
        IndexKey k = key_from_record(kv.second->spec(), recno);
        kv.second->insert(std::move(k), recno);
    }
    dirty_ = true;
}
void IndexManager::on_pack(std::function<int(int)> recnoRemap) {
    std::unordered_map<std::string, std::unique_ptr<IndexTag>> rebuilt;
    for (auto& kv : tags_) {
        auto spec = kv.second->spec();
        auto tag = std::make_unique<IndexTag>(spec);
        std::vector<KeyRec> rows;
        int n = db_record_count(area_);
        rows.reserve(n>0?n:0);
        for (int rec=1; rec<=n; ++rec) {
            if (db_is_deleted(area_, rec)) continue;
            IndexKey k = key_from_record(spec, rec);
            int newRec = recnoRemap ? recnoRemap(rec) : rec;
            rows.push_back(KeyRec{ std::move(k), newRec });
        }
        tag->bulk_build(std::move(rows));
        rebuilt[spec.tag] = std::move(tag);
    }
    tags_ = std::move(rebuilt);
    dirty_ = true;
}
void IndexManager::on_zap() {
    tags_.clear();
    active_tag_.clear();
    dirty_ = true;
}

// Persistence stubs — keep simple and robust
bool IndexManager::save_json(const std::string& path) { (void)path; return true; }
bool IndexManager::load_json(const std::string& path) { (void)path; return false; }

// ===== Introspection =====
std::vector<std::string> IndexManager::listTags() const {
    std::vector<std::string> out; out.reserve(tags_.size());
    for (auto const& kv : tags_) out.push_back(kv.first);
    return out;
}

std::string IndexManager::exprFor(const std::string& tag) const {
    auto it = tags_.find(tag);
    if (it == tags_.end()) return {};
    const auto& sp = it->second->spec();
    std::string expr;
    for (size_t i=0; i<sp.fields.size(); ++i) {
        if (i) expr += "+";
        expr += sp.fields[i];
    }
    return expr;
}

} // namespace xindex
