// shell.cpp   restored command registry + indexing hooks
#include <iostream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <array>
#include <cctype>                 // <-- add this for std::isspace

#include "command_registry.hpp"
#include "xbase.hpp"
#include "textio.hpp"
#include "colors.hpp"
#include "cmd_version.hpp"
#include "cmd_help.hpp"
#include "order_state.hpp"
#include "shell_api.hpp"
#include "parse.hpp"

using xbase::DbArea;

// ---- Core command handlers (extern/forward decls) ----
void cmd_USE   (xbase::DbArea&, std::istringstream&);
void cmd_CLOSE (xbase::DbArea&, std::istringstream&);
void cmd_LIST  (xbase::DbArea&, std::istringstream&);
void cmd_COPY  (xbase::DbArea&, std::istringstream&);
void cmd_EXPORT(xbase::DbArea&, std::istringstream&);
void cmd_IMPORT(xbase::DbArea&, std::istringstream&);
void cmd_APPEND(xbase::DbArea&, std::istringstream&);
void cmd_TOP   (xbase::DbArea&, std::istringstream&);
void cmd_BOTTOM(xbase::DbArea&, std::istringstream&);
void cmd_GOTO  (xbase::DbArea&, std::istringstream&);
void cmd_COUNT (xbase::DbArea&, std::istringstream&);
void cmd_DISPLAY(xbase::DbArea&, std::istringstream&);
void cmd_DELETE(xbase::DbArea&, std::istringstream&);
void cmd_RECALL(xbase::DbArea&, std::istringstream&);
void cmd_PACK  (xbase::DbArea&, std::istringstream&);
void cmd_COLOR (xbase::DbArea&, std::istringstream&);
void cmd_FIELDS(xbase::DbArea&, std::istringstream&);
void cmd_FIND  (xbase::DbArea&, std::istringstream&);
void cmd_SEEK  (xbase::DbArea&, std::istringstream&);
void cmd_SETORDER (xbase::DbArea&, std::istringstream&);

#if DOTTALK_WITH_INDEX
void cmd_INDEX    (xbase::DbArea&, std::istringstream&);
void cmd_SETINDEX (xbase::DbArea&, std::istringstream&);
void cmd_ASCEND   (xbase::DbArea&, std::istringstream&);
void cmd_DESCEND  (xbase::DbArea&, std::istringstream&);
#endif

void cmd_CLEAR(xbase::DbArea&, std::istringstream&);
void cmd_COLOR(xbase::DbArea&, std::istringstream&);
void cmd_CREATE(xbase::DbArea&, std::istringstream&);
void cmd_DUMP(xbase::DbArea&, std::istringstream&);
void cmd_EDIT(xbase::DbArea&, std::istringstream&);
void cmd_RECNO(xbase::DbArea&, std::istringstream&);
void cmd_REFRESH(xbase::DbArea&, std::istringstream&);
void cmd_REPLACE(xbase::DbArea&, std::istringstream&);
void cmd_STATUS(xbase::DbArea&, std::istringstream&);
void cmd_STRUCT(xbase::DbArea&, std::istringstream&);
void cmd_DIR       (xbase::DbArea&, std::istringstream&);
void cmd_BANG      (xbase::DbArea&, std::istringstream&);
void cmd_FOXHELP   (xbase::DbArea&, std::istringstream&);
void cmd_FH        (xbase::DbArea&, std::istringstream&);
void cmd_TEST      (xbase::DbArea&, std::istringstream&);
void cmd_T         (xbase::DbArea&, std::istringstream&);

// ---- global-scope helper ----
// Re-implemented to use your registry().run(DbArea&, CMD, stream)
bool shell_dispatch_line(xbase::DbArea& a, const std::string& line) {
    if (!line.empty()) std::cout << "[input] " << line << "\n";

    std::string trimmed = textio::trim(line);
    if (trimmed.empty()) return true;

    std::istringstream iss(trimmed);
    std::string cmd;
    iss >> cmd;
    if (cmd.empty()) return true;

    std::string U = textio::up(cmd);
    return cli::registry().run(a, U, iss);
}

int run_shell()
{
    using namespace xbase;

#ifdef DOTTALK_WITH_COLORS
  #include "colors.hpp"
  colors::applyTheme(colors::Theme::Green);
  struct ResetAtExit { ~ResetAtExit(){ colors::reset(); } } _reset_guard;
#endif

    XBaseEngine eng;
    eng.selectArea(0);

    // --- Register commands -------------------------------------------------
    cli::registry().add("USE",     [](DbArea& A, std::istringstream& S){ cmd_USE(A,S); });

    // Avoid unknown MAX_AREA symbol; keep simple usage text.
    cli::registry().add("SELECT",  [&](DbArea& /*A*/, std::istringstream& S){
        int n; S >> n;
        if (!S) {
            std::cout << "Usage: SELECT <area>\n";
            return;
        }
        eng.selectArea(n);
        std::cout << "Selected area " << n << ".\n";

        DbArea& cur = eng.area(eng.currentArea());
        std::cout << "Current area: " << eng.currentArea() << "\n";
        if (cur.isOpen()) {
            std::cout << "  File: " << cur.name()
                      << "  Recs: " << cur.recCount()
                      << "  Recno: " << cur.recno() << "\n";
        } else {
            std::cout << "  (no file open)\n";
        }
    });

    cli::registry().add("AREA",    [&](DbArea&, std::istringstream&){
        int i = eng.currentArea();
        DbArea& cur = eng.area(i);
        std::cout << "Current area: " << i << "\n";
        if (cur.isOpen()) {
            std::cout << "  File: " << cur.name()
                      << "  Recs: " << cur.recCount()
                      << "  Recno: " << cur.recno() << "\n";
            try {
                bool asc = orderstate::isAscending(cur);
                std::string tag = orderstate::hasOrder(cur) ? orderstate::orderName(cur) : std::string("(none)");
                std::cout << "  Order: " << (asc ? "ASCEND" : "DESCEND")
                          << "  Active tag: " << tag << "\n";
            } catch (...) {}
        } else {
            std::cout << "  (no file open)\n";
        }
    });

    // (rest of your registry calls unchanged…)
    // ...
    // FIND/SEEK
    cli::registry().add("FIND", cmd_FIND);
    cli::registry().add("SEEK", cmd_SEEK);

#if DOTTALK_WITH_INDEX
    cli::registry().add("INDEX",       [](DbArea& A, std::istringstream& S){ cmd_INDEX(A,S); });
    cli::registry().add("SETINDEX",    [](DbArea& A, std::istringstream& S){ cmd_SETINDEX(A,S); });
    cli::registry().add("SET INDEX",   [](DbArea& A, std::istringstream& S){ cmd_SETINDEX(A,S); });
    cli::registry().add("SET INDEX TO",[](DbArea& A, std::istringstream& S){ cmd_SETINDEX(A,S); });
    cli::registry().add("ASCEND",      [](DbArea& A, std::istringstream& S){ cmd_ASCEND(A,S); });
    cli::registry().add("DESCEND",     [](DbArea& A, std::istringstream& S){ cmd_DESCEND(A,S); });
    cli::registry().add("SETORDER",    [](DbArea& A, std::istringstream& S){ cmd_SETORDER(A,S); });
    cli::registry().add("SET ORDER",   [](DbArea& A, std::istringstream& S){ cmd_SETORDER(A,S); });
#endif

    // System / utilities
    cli::registry().add("DIR",     [](DbArea& A, std::istringstream& S){ cmd_DIR(A,S);   });
    cli::registry().add("FOXHELP", [](DbArea& A, std::istringstream& S){ cmd_FOXHELP(A,S); });
    cli::registry().add("FH",      [](DbArea& A, std::istringstream& S){ cmd_FH(A,S); });
    cli::registry().add("!",       [](DbArea& A, std::istringstream& S){ cmd_BANG(A,S);  });

    cli::registry().add("HELP",    [](DbArea& A, std::istringstream& S){ cmd_HELP(A,S); });
    cli::registry().add("?",       [](DbArea& A, std::istringstream& S){ cmd_HELP(A,S); });
    cli::registry().add("TEST",    [](DbArea& A, std::istringstream& in){ cmd_TEST(A, in); });
    cli::registry().add("T",       [](DbArea& A, std::istringstream& in){ cmd_TEST(A, in); });

    cli::registry().add("COLOR",   [](DbArea& A, std::istringstream& in){ cmd_COLOR(A, in); });

    // debug wires:
    std::cout << "[wire] FIND -> " << (void*)&cmd_FIND << "\n";
    std::cout << "[wire] SEEK -> " << (void*)&cmd_SEEK  << "\n";

    std::cout << "DotTalk++ type HELP. USE, SELECT <n>, AREA, COLOR <GREEN|AMBER|DEFAULT>, QUIT.\n";

    // --- REPL ---
    std::string line;
    while (true) {
        std::cout << "> " << std::flush;
        if (!std::getline(std::cin, line)) break;

        // Skip comments and leading whitespace
        {
            size_t i = 0;
            while (i < line.size() && std::isspace(static_cast<unsigned char>(line[i]))) ++i;
            if (i < line.size() && (line[i] == '#' || (line[i] == '/' && i+1 < line.size() && line[i+1] == '/'))) {
                continue;
            }
        }

        line = textio::trim(line);
        if (line.empty()) continue;

        std::istringstream iss(line);
        std::string cmd; iss >> cmd;
        std::string U = textio::up(cmd);

        if (U == "QUIT" || U == "EXIT") break;

        DbArea& cur = eng.area(eng.currentArea());
        if (!cli::registry().run(cur, U, iss)) {
            std::cout << "Unknown command: " << cmd << "\n";
        }
    }
    return 0;
}
