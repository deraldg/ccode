#pragma once
#include <string>
#include "order_state.hpp"  // for orderstate::{setAscending,isAscending}


namespace xbase { class DbArea; }

namespace orderstate {

// Does this area currently have an order (index) attached?
bool hasOrder(const xbase::DbArea& a);

// User-facing name/path of the current order, or empty if none.
std::string orderName(const xbase::DbArea& a);

// Attach an order by path (e.g., "students.inx").
void setOrder(xbase::DbArea& a, const std::string& path);

// Clear order for this area (fall back to natural/physical order).
void clearOrder(xbase::DbArea& a);

// Ascending/descending flag for current order (default true).
void setAscending(xbase::DbArea& a, bool asc);
bool isAscending(const xbase::DbArea& a);

} // namespace orderstate

namespace cli {

// asc == true  -> ascending; asc == false -> descending
void OrderController::setAscending(bool asc) {
    orderstate::setAscending(area_, asc);
}

bool OrderController::isAscending() const {
    // If you already have this, keep your existing version.
    // Otherwise, this delegates to the order_state helper.
    return orderstate::isAscending(area_);
}

} // namespace cli


/*
void OrderController::setDescending() {
    orderstate::setAscending(area_, false);
}

void OrderController::toggleAscending() {
    bool nowAsc = orderstate::isAscending(area_);
    orderstate::setAscending(area_, !nowAsc);
}
*/
