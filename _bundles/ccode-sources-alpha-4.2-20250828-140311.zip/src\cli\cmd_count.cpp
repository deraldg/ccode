// src/cli/cmd_count.cpp
#include "xbase.hpp"
#include "textio.hpp"
#include "predicate_eval.hpp"   // predx::eval_expr

#include <sstream>
#include <iostream>
#include <string>

// Strip FoxPro-style inline comments (everything after "&&")
static std::string strip_inline_comments(std::string s) {
    auto p = s.find("&&");
    if (p != std::string::npos) s.erase(p);
    return textio::trim(std::move(s));
}

enum class DelMode { SkipDeleted, IncludeDeleted, OnlyDeleted };

void cmd_COUNT(xbase::DbArea& db, std::istringstream& iss) {
    if (!db.isOpen()) { std::cout << "0\n"; return; }

    // Parse optional first token: ALL | DELETED
    DelMode delMode = DelMode::SkipDeleted;
    {
        std::streampos save = iss.tellg();
        std::string t;
        if (iss >> t) {
            if (textio::ieq(t, "ALL"))      delMode = DelMode::IncludeDeleted;
            else if (textio::ieq(t, "DELETED")) delMode = DelMode::OnlyDeleted;
            else { iss.clear(); iss.seekg(save); }
        }
    }

    // Get the rest of the line as an optional expression (may start with FOR or not)
    std::string rest;
    {
        std::string tail;
        std::getline(iss, tail);
        rest = strip_inline_comments(std::move(tail));
    }

    // If empty: no predicate; if not: predx::eval_expr handles both
    //  - "FOR fld op rhs" and "fld op rhs"
    const bool haveExpr = !rest.empty();

    long long total = 0;

    // Robust sequential scan (same shape as LOCATE; first-read guard)
    if (!db.top() || !db.readCurrent()) {
        std::cout << "0\n";
        return;
    }

    do {
        // apply deleted-row mode
        const bool isDel = db.isDeleted();
        if (delMode == DelMode::SkipDeleted && isDel)   continue;
        if (delMode == DelMode::OnlyDeleted && !isDel)  continue;

        // optional FOR filter (same shared evaluator as LOCATE)
        if (haveExpr && !predx::eval_expr(db, rest))    continue;

        ++total;
    } while (db.skip(+1) && db.readCurrent());

    std::cout << total << "\n";
}
