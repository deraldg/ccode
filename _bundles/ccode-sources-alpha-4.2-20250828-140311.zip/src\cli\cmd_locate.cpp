// src/cli/cmd_locate.cpp
#include <iostream>
#include <sstream>
#include <string>

#include "textio.hpp"
#include "xbase.hpp"
#include "command_registry.hpp"
#include "predicate_eval.hpp"   // <- new shared typed evaluator

// Strip FoxPro-style inline comments (everything after "&&")
static std::string strip_inline_comments(std::string s) {
    auto p = s.find("&&");
    if (p != std::string::npos) s.erase(p);
    return textio::trim(std::move(s));
}

// LOCATE [FOR <field> <op> <value>]  or  LOCATE <field> <op> <value>
void cmd_LOCATE(xbase::DbArea& db, std::istringstream& iss) {
    if (!db.isOpen()) {
        std::cout << "No table is open. Use USE <file> first.\n";
        return;
    }

    // Recreate the raw arg string from iss and normalize it.
    std::string expr;
    {
        const std::string& all = iss.str();
        auto pos = iss.tellg();
        if (pos != std::istringstream::pos_type(-1)) {
            const size_t i = static_cast<size_t>(pos);
            if (i < all.size()) expr = all.substr(i);
        } else {
            expr = all;
        }
    }
    expr = strip_inline_comments(std::move(expr));
    if (expr.empty()) {
        std::cout << "Syntax: LOCATE [FOR <field> <op> <value>]\n";
        return;
    }

    // Robust linear scan in physical order; stop at first match.
    if (!db.top() || !db.readCurrent()) {
        std::cout << "Not located.\n";
        return;
    }

    do {
        // predx::eval_expr handles both "FOR fld op val" and "fld op val",
        // and is type-aware (C/N/D/L) with = != > >= < <= and $ for strings.
        if (predx::eval_expr(db, expr)) {
            std::cout << "Located at " << db.recno() << ".\n";
            return;
        }
    } while (db.skip(+1) && db.readCurrent());

    std::cout << "Not located.\n";
}

// Self-register with the command registry
static bool s_registered = [](){
    cli::registry().add("LOCATE", &cmd_LOCATE);
    return true;
}();
