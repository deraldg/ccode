// src/cli/cmd_count.cpp
#include "xbase.hpp"
#include "record_view.hpp"
#include "textio.hpp"
#include "predicate_eval.hpp"  // predx::eval_expr, predx::get_case_sensitive()

#include <iostream>
#include <sstream>
#include <string>
#include <cctype>
#include <algorithm>
#include <cstdlib>

namespace {

// ---------- small utils ----------
static inline std::string trim(std::string s) {
    auto sp = [](unsigned char c){ return c==' '||c=='\t'||c=='\r'||c=='\n'; };
    while (!s.empty() && sp((unsigned char)s.front())) s.erase(s.begin());
    while (!s.empty() && sp((unsigned char)s.back()))  s.pop_back();
    return s;
}
static inline std::string dequote(std::string s) {
    s = trim(std::move(s));
    if (s.size() >= 2) {
        char a = s.front(), b = s.back();
        if ((a=='"' && b=='"') || (a=='\'' && b=='\'')) return s.substr(1, s.size()-2);
    }
    return s;
}
static inline std::string upper(std::string s) {
    for (auto& ch : s) ch = (char)std::toupper((unsigned char)ch);
    return s;
}
static inline bool ieq(const std::string& a, const std::string& b) {
    if (a.size()!=b.size()) return false;
    for (size_t i=0;i<a.size();++i)
        if (std::toupper((unsigned char)a[i]) != std::toupper((unsigned char)b[i])) return false;
    return true;
}
static inline bool parse_double(const std::string& s, double& out) {
    if (s.empty()) return false;
    char* end=nullptr; out = std::strtod(s.c_str(), &end);
    return end && *end=='\0';
}
static inline bool is_bool_true(std::string s) {
    s = upper(trim(std::move(s)));
    return (s=="T" || s==".T." || s=="TRUE" || s=="1");
}
static inline bool is_bool_false(std::string s) {
    s = upper(trim(std::move(s)));
    return (s=="F" || s==".F." || s=="FALSE" || s=="0");
}

// ---------- field helpers ----------
static int resolve_field_index(xbase::DbArea& db, const std::string& nameIn) {
    const auto name = upper(trim(nameIn));
    const auto F = db.fields();
    for (int i = 0; i < (int)F.size(); ++i) {
        if (upper(trim(F[i].name)) == name) return i;
    }
    return -1;
}
static std::string get_cur_string(xbase::DbArea& db, int fi) {
    RecordView rv(db);
    return textio::rtrim(rv.getString(fi));
}

// ---------- CLI parse ----------
struct Opts {
    enum Mode { SkipDeleted, IncludeDeleted, OnlyDeleted } mode{SkipDeleted};
    bool haveTriplet{false};
    std::string fld, op, val;   // when FOR <fld> <op> <value> present
};

// parse: [ALL|DELETED] [FOR <fld> <op> <value...>]
static Opts parse_opts(std::istringstream& iss) {
    Opts o{};
    std::string tok;

    auto strip_line_comment = [](std::string& s){
        auto p = s.find("&&");
        if (p != std::string::npos) s.erase(p);
    };

    // Optional leading: ALL | DELETED
    std::streampos save = iss.tellg();
    if (iss >> tok) {
        if (textio::ieq(tok, "ALL"))          o.mode = Opts::IncludeDeleted;
        else if (textio::ieq(tok, "DELETED")) o.mode = Opts::OnlyDeleted;
        else { iss.clear(); iss.seekg(save); }
    }

    // Optional: FOR <fld> <op> <value...>
    save = iss.tellg();
    std::string kw;
    if (iss >> kw) {
        if (textio::ieq(kw, "FOR")) {
            std::string fld, op;
            if ((iss >> fld) && (iss >> op)) {
                std::string rest; std::getline(iss, rest);
                strip_line_comment(rest);
                o.fld = trim(fld);
                o.op  = trim(op);
                o.val = trim(rest);
                o.haveTriplet = (!o.fld.empty() && !o.op.empty() && !o.val.empty());
            }
        } else {
            iss.clear(); iss.seekg(save);
        }
    }
    return o;
}

// ---------- type-aware key normalization ----------
enum class KeyKind { Str, Num, Bool, Bad };

// Normalize RHS to comparable form based on field type.
static KeyKind normalize_rhs_for_field(char fieldType, const std::string& rhsRaw,
                                       std::string& outStr, double& outNum, bool& outBool)
{
    const auto rhs = dequote(trim(rhsRaw));
    switch (std::toupper((unsigned char)fieldType)) {
        case 'C': {
            outStr = rhs;
            if (!predx::get_case_sensitive()) outStr = upper(outStr);
            return KeyKind::Str;
        }
        case 'N': {
            if (!parse_double(rhs, outNum)) return KeyKind::Bad;
            return KeyKind::Num;
        }
        case 'D': {
            // Accept YYYYMMDD as numeric compare
            if (!parse_double(rhs, outNum)) return KeyKind::Bad;
            return KeyKind::Num;
        }
        case 'L': {
            if (is_bool_true(rhs))  { outBool = true;  return KeyKind::Bool; }
            if (is_bool_false(rhs)) { outBool = false; return KeyKind::Bool; }
            return KeyKind::Bad;
        }
        default: {
            outStr = rhs;
            if (!predx::get_case_sensitive()) outStr = upper(outStr);
            return KeyKind::Str;
        }
    }
}

static KeyKind normalize_lhs_field_value(xbase::DbArea& A, int fi,
                                         std::string& outStr, double& outNum, bool& outBool)
{
    const char t = static_cast<char>(std::toupper((unsigned char)A.fields()[fi].type));
    switch (t) {
        case 'C': {
            outStr = get_cur_string(A, fi);
            if (!predx::get_case_sensitive()) outStr = upper(outStr);
            return KeyKind::Str;
        }
        case 'N':
        case 'D': {
            std::string s = get_cur_string(A, fi);
            if (!parse_double(s, outNum)) return KeyKind::Bad;
            return KeyKind::Num;
        }
        case 'L': {
            std::string s = upper(trim(get_cur_string(A, fi)));
            if (is_bool_true(s))  { outBool = true;  return KeyKind::Bool; }
            if (is_bool_false(s)) { outBool = false; return KeyKind::Bool; }
            return KeyKind::Bad;
        }
        default: {
            outStr = get_cur_string(A, fi);
            if (!predx::get_case_sensitive()) outStr = upper(outStr);
            return KeyKind::Str;
        }
    }
}

template <class T> static int cmp(const T& a, const T& b) {
    if (a < b) return -1; if (a > b) return +1; return 0;
}

// Heuristic: is the current view ordered by this field? (ASC/DESC) — sampling only.
// NOTE: We do NOT restore the cursor; fast path will restart from TOP anyway.
enum class SortSense { None, Asc, Desc };
static SortSense detect_sorted_by_field(xbase::DbArea& A, int fi, int maxSample = 48) {
    if (!(A.top() && A.readCurrent())) return SortSense::None;

    int ascOK = 1, descOK = 1;
    std::string sPrev, sCur; double nPrev=0, nCur=0; bool bPrev=false, bCur=false;

    KeyKind kindPrev = normalize_lhs_field_value(A, fi, sPrev, nPrev, bPrev);
    int sampled = 0;

    while (sampled < maxSample) {
        if (!A.skip(+1) || !A.readCurrent()) break;
        KeyKind kindCur = normalize_lhs_field_value(A, fi, sCur, nCur, bCur);
        if (kindCur != kindPrev) { ascOK = descOK = 0; break; }

        int rel = 0;
        if (kindCur == KeyKind::Str)  rel = cmp(sCur, sPrev);
        if (kindCur == KeyKind::Num)  rel = (nCur < nPrev ? -1 : (nCur > nPrev ? +1 : 0));
        if (kindCur == KeyKind::Bool) rel = (int)bCur - (int)bPrev;

        if (rel < 0) ascOK = 0;
        if (rel > 0) descOK = 0;

        sPrev = sCur; nPrev = nCur; bPrev = bCur;
        ++sampled;
    }

    if (ascOK && !descOK)  return SortSense::Asc;
    if (!ascOK && descOK)  return SortSense::Desc;
    if (ascOK && descOK)   return SortSense::Asc; // constant field — treat as ASC
    return SortSense::None;
}

// Attempt fast path: only for "=" or "==" with a plain field LHS, and view sorted by that field.
// Returns true if handled (outCnt is valid).
static bool fast_count_eq_if_sorted(xbase::DbArea& A, const Opts& o,
                                    int fi, const std::string& opRaw, const std::string& rhsRaw,
                                    long long& outCnt)
{
    const std::string op = upper(trim(opRaw));
    if (!(op == "=" || op == "==")) return false;

    SortSense sense = detect_sorted_by_field(A, fi);
    if (sense == SortSense::None) return false;

    const char ftype = static_cast<char>(std::toupper((unsigned char)A.fields()[fi].type));
    std::string rhsS; double rhsN=0; bool rhsB=false;
    KeyKind rhsK = normalize_rhs_for_field(ftype, rhsRaw, rhsS, rhsN, rhsB);
    if (rhsK == KeyKind::Bad) return false;

    outCnt = 0;
    if (!(A.top() && A.readCurrent())) return true; // empty view

    auto include_row = [&](bool deleted)->bool {
        if (o.mode == Opts::SkipDeleted && deleted) return false;
        if (o.mode == Opts::OnlyDeleted && !deleted) return false;
        return true;
    };

    auto key_cmp = [&](int& rel)->bool {
        std::string s; double n=0; bool b=false;
        KeyKind lk = normalize_lhs_field_value(A, fi, s, n, b);
        if (lk != rhsK) return false; // type mismatch => bail to general path
        if (lk == KeyKind::Str)  rel = cmp(s, rhsS);
        if (lk == KeyKind::Num)  rel = (n < rhsN ? -1 : (n > rhsN ? +1 : 0));
        if (lk == KeyKind::Bool) rel = (int)b - (int)rhsB;
        return true;
    };

    do {
        int rel = 0;
        if (!key_cmp(rel)) return false;

        if (sense == SortSense::Asc) {
            if (rel < 0) { continue; }    // below target
            if (rel > 0) { break; }       // passed target
            // equal block
            if (include_row(A.isDeleted())) ++outCnt;
            while (A.skip(+1) && A.readCurrent()) {
                int r2 = 0; if (!key_cmp(r2)) return false;
                if (r2 != 0) { break; }
                if (include_row(A.isDeleted())) ++outCnt;
            }
            return true;
        } else { // Desc
            if (rel > 0) { continue; }    // above target
            if (rel < 0) { break; }       // went past
            if (include_row(A.isDeleted())) ++outCnt;
            while (A.skip(+1) && A.readCurrent()) {
                int r2 = 0; if (!key_cmp(r2)) return false;
                if (r2 != 0) { break; }
                if (include_row(A.isDeleted())) ++outCnt;
            }
            return true;
        }
    } while (A.skip(+1) && A.readCurrent());

    return true;
}

} // namespace

// ========== COUNT entry ==========
void cmd_COUNT(xbase::DbArea& A, std::istringstream& iss) {
    if (!A.isOpen()) { std::cout << "No table open.\n"; return; }

    const Opts opt = parse_opts(iss);

    // Fast path only when FOR <fld> <op> <val> exists and LHS is a plain field.
    if (opt.haveTriplet) {
        const std::string lhsUp = upper(trim(opt.fld));
        const bool hasFunc = (lhsUp.rfind("UPPER(", 0) == 0) || (lhsUp.rfind("LOWER(", 0) == 0);

        int fi = -1;
        if (!hasFunc) fi = resolve_field_index(A, opt.fld);

        long long fastCnt = 0;
        if (!hasFunc && fi >= 0) {
            if (fast_count_eq_if_sorted(A, opt, fi, opt.op, opt.val, fastCnt)) {
                std::cout << fastCnt << "\n";
                return;
            }
        }
    }

    // ----- General path (robust fallback) -----
    long long cnt = 0;

    auto include_row = [&](bool deleted)->bool {
        if (opt.mode == Opts::SkipDeleted && deleted) return false;
        if (opt.mode == Opts::OnlyDeleted && !deleted) return false;
        return true;
    };

    if (A.top() && A.readCurrent()) {
        if (opt.haveTriplet) {
            // Compose "FOR ..." back to the evaluator for exact parity
            std::string expr = "FOR " + opt.fld + " " + opt.op + " " + opt.val;
            do {
                if (!include_row(A.isDeleted())) continue;
                if (predx::eval_expr(A, expr)) ++cnt;
            } while (A.skip(+1) && A.readCurrent());
        } else {
            // COUNT (no FOR)
            do {
                if (include_row(A.isDeleted())) ++cnt;
            } while (A.skip(+1) && A.readCurrent());
        }
    }

    std::cout << cnt << "\n";
}
