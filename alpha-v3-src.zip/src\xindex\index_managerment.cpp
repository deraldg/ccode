// src/xindex/index_manager_dtor.cpp
#include "xindex/index_manager.hpp"

namespace xindex {
    IndexManager::~IndexManager() = default;
}
