#pragma once
#include "xbase.hpp"
#include <sstream>

void cmd_VERSION(xbase::DbArea& area, std::istringstream& args);
