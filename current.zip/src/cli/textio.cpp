// Intentionally empty — text I/O helpers are header-only.
// See include/textio.hpp.
#include "textio.hpp"
