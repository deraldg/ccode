#include "xbase.hpp"

// Intentionally empty translation unit reserved for future field helpers.
// Keeping the library layout stable for upcoming features (indexes, types).
