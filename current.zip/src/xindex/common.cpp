#include "xindex/key_common.hpp"

// Intentionally empty. If you had a duplicate KeyLess here before, it is removed.
