#include "xindex/key_codec.hpp"
// Header-only for now; TU reserved for future growth (locale/collation tables, etc.).
