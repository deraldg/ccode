# DotTalk++ Expression Engine — Milestone 1 Scaffolding

This package adds a self-contained expression layer for `FOR <expr>` logic to use in commands like
`COUNT FOR ...` and `LOCATE FOR ...` (and later, `LIST FOR ...`).

Scope in this milestone:
- Literals: strings `"..."`, integers (parsed to double)
- Identifiers for fields
- Comparisons: `=`, `==`, `!=`, `<`, `<=`, `>`, `>=`
- Boolean ops: `NOT`, `AND`, `OR` (and dotted `.NOT. .AND. .OR.`)
- Parentheses `(` `)`
- Case-insensitive keywords
- Short-circuit AND/OR
- Simple string/numeric coercion

Out of scope for M1 (planned for M3+):
- String contains `$` / `!$`
- `SET EXACT` & locale rules
- Index fast-path rewrite

## File layout
- `include/dottalk/expr/token.hpp` — token kinds and Token struct
- `include/dottalk/expr/lexer.hpp` — Lexer class
- `include/dottalk/expr/ast.hpp` — AST node classes
- `include/dottalk/expr/parser.hpp` — Pratt parser
- `include/dottalk/expr/eval.hpp` — Evaluator helpers
- `include/dottalk/expr/api.hpp` — `compile_where(text)` public entry
- `src/lexer.cpp`, `src/parser.cpp`, `src/eval.cpp`, `src/api.cpp` — impl
- `examples/demo.cpp` — minimal integration example (no xbase deps)

## Integrating with your CLI

Provide a `RecordView` adapter that knows how to fetch fields of the current record.

```
#include "dottalk/expr/api.hpp"

using namespace dottalk::expr;

RecordView rv;
rv.get_field_str = [&](std::string_view name){ return db.getFieldAsString(name); };
rv.get_field_num = [&](std::string_view name)->std::optional<double>{ return db.getFieldAsNumber(name); };

auto where = compile_where('AGE >= 50 AND STATE = "OR"');
if (!where) { /* report where.error */ }

auto pred = std::move(where->program);  // unique_ptr<Expr>
bool ok = pred->eval(rv);
```

### COUNT
- Parse once per command invocation.
- Iterate visible records; `if (pred->eval(rv)) ++count;`

### LOCATE
- Parse once; iterate until true; move cursor and stop.

## Build (standalone)
```
mkdir build && cd build
cmake .. && cmake --build . --config Release
./demo
```
