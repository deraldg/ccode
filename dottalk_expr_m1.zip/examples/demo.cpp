#include <iostream>
#include <unordered_map>
#include "dottalk/expr/api.hpp"

using namespace dottalk::expr;

int main() {
  // Fake record for demonstration
  std::unordered_map<std::string, std::string> rec{
    {"AGE","55"},
    {"STATE","OR"},
    {"STATUS","ACTIVE"},
    {"CITY","EUGENE"}
  };

  RecordView rv;
  rv.get_field_str = [&](std::string_view name)->std::string {
    auto it = rec.find(std::string(name));
    return (it==rec.end())? std::string() : it->second;
  };
  rv.get_field_num = [&](std::string_view name)->std::optional<double> {
    auto it = rec.find(std::string(name));
    if (it==rec.end()) return std::nullopt;
    try { return std::stod(it->second); } catch(...) { return std::nullopt; }
  };

  auto r = compile_where("AGE >= 50 AND STATE = "OR" AND NOT (STATUS = "INACTIVE")");
  if (!r) {
    std::cerr << "Parse error: " << r.error << "\n";
    return 1;
  }
  bool ok = r.program->eval(rv);
  std::cout << "Eval -> " << (ok? "true":"false") << "\n";
  return ok? 0: 2;
}
