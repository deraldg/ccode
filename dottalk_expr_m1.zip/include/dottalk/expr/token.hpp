#pragma once
#include <string>
#include <string_view>

namespace dottalk { namespace expr {

enum class TokKind {
  End,
  Ident,
  Number,
  String,
  // symbols
  Eq,     // =
  EqEq,   // ==
  Ne,     // !=
  Lt,     // <
  Le,     // <=
  Gt,     // >
  Ge,     // >=
  LParen, // (
  RParen, // )
  // keywords
  KW_NOT,
  KW_AND,
  KW_OR
};

struct Token {
  TokKind kind{TokKind::End};
  std::string lexeme; // original slice (upper-cased for keywords/operators where helpful)
  double number{0.0};
};

}} // namespace
