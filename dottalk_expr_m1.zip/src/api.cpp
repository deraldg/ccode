#include "dottalk/expr/api.hpp"
#include "dottalk/expr/parser.hpp"

using namespace dottalk::expr;

CompileResult compile_where(const std::string& text) {
  try {
    Parser p(text);
    auto e = p.parse_expr();
    // Optional: ensure we've consumed to End (relaxed for now)
    return CompileResult{ std::move(e), "" };
  } catch (const ParseError& pe) {
    return CompileResult{ nullptr, pe.message };
  } catch (...) {
    return CompileResult{ nullptr, "Unknown parse error" };
  }
}
