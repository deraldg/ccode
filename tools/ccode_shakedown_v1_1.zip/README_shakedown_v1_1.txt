Shakedown v1.1 (synchronized with current CLI)

Fixes vs v1.0:
- Removed inline comment lines ('# ...') that the CLI treats as commands.
- SEEK now uses 'SEEK <field> <value>' as per your Usage message.
- FIND uses 'FIND <field> <needle>'.
- EXPORT honors current behavior (always writes '<table>.csv'); script uses TEMP.csv.
- IMPORT targets existing TEMP from TEMP.csv to validate the pipeline without filesystem tricks.
