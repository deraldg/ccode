
<#
  DotTalk++ Shakedown Script v1.1 (aligned with current CLI behavior)
  Usage (from repo root):
    .\tools\shakedown_ccode_v1_1.ps1 [-Config Release|Debug]
#>

[CmdletBinding()]
param(
  [ValidateSet("Release","Debug")]
  [string]$Config = "Release"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

# Discover repo root and exe
$Repo     = Split-Path -Parent $MyInvocation.MyCommand.Path | Split-Path -Parent
$BuildDir = Join-Path $Repo "build"
$Target   = "dottalkpp"
$ExePath  = Join-Path $BuildDir "$Config\$Target.exe"

if (-not (Test-Path -LiteralPath $ExePath)) {
  throw "Executable not found: $ExePath`nRun .\tools\rebuild_ccode.ps1 first."
}

# Workspace
$OutDir = Join-Path $Repo "_shakedown"
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$stamp  = Get-Date -Format "yyyyMMdd-HHmmss"
$Log    = Join-Path $OutDir "shakedown-v1_1-$Config-$stamp.log"

Write-Host ">>> Shakedown v1.1 starting ($Config)" -ForegroundColor Cyan
Write-Host "Log: $Log"

# Compose scripted session (NO comment lines; CLI treats '#' as command)
$cmds = @'
HELP
COLOR DEFAULT
CLEAR
CREATE TEMP (ID N(5), FIRST_NAME C(20), LAST_NAME C(20), DOB D, GPA N(4,2), IS_ACTIVE L)
APPEND
APPEND 2
APPEND BLANK
APPEND -B 3
COUNT
BOTTOM 1
RECNO
DISPLAY
GOTO 1
REPLACE FIRST_NAME WITH "ALICE"
REPLACE LAST_NAME  WITH "ZEKE"
REPLACE GPA        WITH 3.14
REPLACE IS_ACTIVE  WITH T
DISPLAY
INDEX ON LAST_NAME TAG L
TOP
LIST 3
SEEK LAST_NAME "ZEKE"
DISPLAY
FIND FIRST_NAME "ALICE"
DELETE
RECALL
PACK
STATUS
STRUCT
EXPORT TEMP TO TEMP.csv
USE
CREATE T2 (X N(3), Y C(10))
USE TEMP
IMPORT TEMP FROM TEMP.csv FIELDS (FIRST_NAME AS Y, ID AS X) LIMIT 3
USE TEMP
LIST 5
APPEND FROG
APPEND -B X
APPEND -7
STATUS
QUIT
'@

# Launch process and pipe commands
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $ExePath
$psi.RedirectStandardInput  = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError  = $true
$psi.UseShellExecute = $false
$proc = New-Object System.Diagnostics.Process
$proc.StartInfo = $psi

$null = $proc.Start()
$proc.StandardInput.WriteLine($cmds)
$proc.StandardInput.Close()

$stdout = $proc.StandardOutput.ReadToEnd()
$stderr = $proc.StandardError.ReadToEnd()
$proc.WaitForExit()

$stdout | Set-Content -Path $Log -Encoding UTF8
if ($stderr) {
  "`n--- STDERR ---`n$stderr" | Add-Content -Path $Log -Encoding UTF8
}

# Assertions aligned to current behavior
$failures = @()

function Assert-Seen($pattern, $desc) {
  if ($stdout -notmatch $pattern) {
    $failures += "Missing: $desc"
  }
}

function Assert-NotSeen($pattern, $desc) {
  if ($stdout -match $pattern) {
    $failures += "Unexpected: $desc"
  }
}

Assert-Seen "Created TEMP\.dbf"                         "Create TEMP"
Assert-Seen "Appended 1 blank record\."                 "Append 1"
Assert-Seen "Appended 2 blank records\."                "Append 2"
Assert-Seen "Appended 3 blank records\."                "Append -B 3"
Assert-Seen "Replaced FIRST_NAME"                       "Replace FIRST_NAME"
Assert-Seen "Index written:.*\(expr: LAST_NAME"         "Index on LAST_NAME"
Assert-Seen "Recno:\s*1"                                "TOP moved to first record"
Assert-Seen "Usage: SEEK <field> <value>"               "SEEK usage exists"
Assert-Seen "Usage: FIND <field> <needle>"              "FIND usage exists"
Assert-Seen "PACK complete"                             "PACK completed"
Assert-Seen "Exported .* to TEMP\.csv"                  "EXPORT created TEMP.csv"
Assert-Seen "Usage: APPEND \[BLANK\|\-B\] \[n\]"        "Bad APPEND usage reported"
Assert-NotSeen "Unknown command"                        "No unknown command errors"
Assert-NotSeen "exception"                              "No raw exception surfaced"

if ($failures.Count -gt 0) {
  Write-Host "Shakedown v1.1 completed with issues:" -ForegroundColor Yellow
  $failures | ForEach-Object { Write-Host " - $_" }
  Write-Host "See log: $Log"
  exit 1
} else {
  Write-Host "Shakedown v1.1 PASSED." -ForegroundColor Green
  Write-Host "Log: $Log"
  exit 0
}
