Cherry-on-top pack for DotTalk++ (safe changes)

Includes:
  • src/cli/cmd_append.cpp           — consolidated APPEND implementation using DbArea::appendBlank()
  • tools/apply_help_tweak.ps1       — small script to update HELP text to match behavior

How to apply:
1) Back up your repo (you already do via bundle.ps1).
2) Copy `src\cli\cmd_append.cpp` into your repo at the same path (overwrite).
3) (Optional) Run the help tweak:
     powershell -ExecutionPolicy Bypass -File .\tools\apply_help_tweak.ps1
4) Rebuild and test:
     .\tools\rebuild_ccode.ps1
     .\tools\smoke_ccode.ps1

Notes:
- APPEND supports: APPEND | APPEND BLANK | APPEND -B | APPEND N | APPEND BLANK N | APPEND -B N
- Interactive APPEND is reserved for later and currently behaves like BLANK.
- We avoided risky "mutation notify" changes for indices to keep this cherry pack safe.
