// src/cli/cmd_append.cpp  (drop-in replacement)
// Consolidates APPEND and APPEND_BLANK behavior.
// Syntax supported:
//   APPEND                     -> append 1 blank record
//   APPEND BLANK               -> append 1 blank record
//   APPEND -B                  -> append 1 blank record
//   APPEND N                   -> append N blank records
//   APPEND BLANK N / APPEND -B N  -> append N blank records
//
// Notes:
// - Uses DbArea::appendBlank() discovered in your codebase.
// - Prints concise success/failure messages.
// - Interactive edit mode reserved for a future change (currently behaves like BLANK).

#include "xbase.hpp"
#include "textio.hpp"
#include <sstream>
#include <string>
#include <cctype>
#include <iostream>

using namespace xbase;

namespace {

inline std::string uptrim(std::string s) {
    return textio::up(textio::trim(s));
}

inline bool try_parse_int(const std::string& s, int& out) {
    try {
        size_t i = 0;
        int v = std::stoi(s, &i);
        if (i == s.size()) { out = v; return true; }
    } catch (...) {}
    return false;
}

// Append N blank records; return false if any append fails
static bool append_n_blank(DbArea& db, int n) {
    if (n <= 0) return true;
    for (int i = 0; i < n; ++i) {
        if (!db.appendBlank()) return false; // ✅ real primitive in this codebase
    }
    return true;
}

} // namespace

// APPEND [BLANK|-B] [n]
void cmd_APPEND(DbArea& db, std::istringstream& iss) {
    std::string t1; // first token after APPEND
    std::string t2; // optional second token (n)

    // read tokens loosely
    iss >> t1;
    iss >> t2;

    const std::string a1 = uptrim(t1);
    const std::string a2 = uptrim(t2);

    int  count   = 1;     // default number of records
    bool doBlank = true;  // classic drop-through

    // Handle forms:
    // 1) APPEND (no args) -> BLANK 1
    // 2) APPEND BLANK [n]
    // 3) APPEND -B [n]
    // 4) APPEND [n]
    if (!a1.empty()) {
        if (a1 == "BLANK" || a1 == "-B") {
            int n;
            if (try_parse_int(a2, n) && n > 0) count = n;
        } else {
            int n;
            if (try_parse_int(a1, n) && n > 0) {
                count = n;  // "APPEND 3" => 3 blanks
            } else {
                // Future: interactive path. For now, treat as BLANK 1.
                doBlank = true;
                count   = 1;
            }
        }
    }

    if (doBlank) {
        if (!append_n_blank(db, count)) {
            std::cout << "APPEND failed.
";
            return;
        }

        // If your index/order layer needs a mutation notice, add it here later.
        // e.g., order_state::notify_mutation(db);

        std::cout << "Appended " << count
                  << " blank record" << (count == 1 ? "" : "s")
                  << ".
";
        return;
    }

    std::cout << "APPEND: interactive mode not yet implemented.
";
}
