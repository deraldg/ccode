\
<#
  Non-invasive help text tweak:
  - Replace "APPEND_BLANK [n]" line with "APPEND [BLANK|-B] [n] ..."
  - Remove "APPEND_BLANK" from the command list if present.
  Usage (from repo root):
    powershell -ExecutionPolicy Bypass -File .\tools\apply_help_tweak.ps1
#>

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$HelpFile = Join-Path (Get-Location) "src\cli\cmd_help.cpp"
if (-not (Test-Path -LiteralPath $HelpFile)) {
  throw "Could not find src\cli\cmd_help.cpp"
}

$content = Get-Content -LiteralPath $HelpFile -Raw

# 1) Replace the usage line for APPEND_BLANK with the consolidated form (if present)
$content = $content -replace '(?m)^\s*<<\s*"APPEND_BLANK\s*\[n\].*$', '        << "APPEND [BLANK|-B] [n]            # append n blank records (default 1)\n"'

# 2) Remove "APPEND_BLANK" from the commands list (lines that look like: two columns with command names)
$content = ($content -split "`n") | ForEach-Object {
  if ($_ -match 'APPEND_BLANK') {
    $_ -replace 'APPEND_BLANK\s*', ''
  } else {
    $_
  }
} | Out-String

Set-Content -LiteralPath $HelpFile -Value $content -Encoding UTF8
Write-Host "Help text updated. Rebuild to see changes." -ForegroundColor Green
