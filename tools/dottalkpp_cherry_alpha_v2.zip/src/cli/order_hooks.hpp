#pragma once
// src/cli/order_hooks.hpp
// Safe, compile-anywhere no-op hooks for index/order notifications.
// You can later provide real implementations without changing call sites.

namespace xbase { class DbArea; }

inline void order_notify_mutation(xbase::DbArea&) noexcept {
    // no-op by default
}

inline void order_auto_top(xbase::DbArea&) noexcept {
    // no-op by default
}
