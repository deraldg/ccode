Parser Debug Kit (for DotTalk++ / ccode repo)
============================================

What this is
-------------
This kit contains a single PowerShell script that *you run on your machine*
to gather parser-related sources, build metadata, toolchain versions, and
optional runtime output into a single timestamped ZIP (a "parser debug zip").

Quick Start
-----------
1) Open PowerShell.
2) cd to your repo root (e.g., C:\Users\deral\code\ccode).
3) Run:
     .\make_parser_debug_zip.ps1 -Verbose
   (Add -ExePath .\build\Release\dottalkpp.exe if you want a short
    runtime trace captured too.)
4) The output ZIP will land under .\_debug\parser-debug-YYYYMMDD-HHMMSS.zip

Common parameters
-----------------
-RepoRoot   : Path to the repo root (defaults to current directory).
-OutDir     : Folder to write the final ZIP (default: .\_debug).
-ExePath    : Optional path to your built CLI (dottalkpp.exe) to capture a
              tiny runtime trace (HELP, then quit).
-IncludeGlobs : Extra file glob patterns to include (array). Examples:
                -IncludeGlobs @('src\xindex\*.{cpp,hpp}','pcode\**\*.*')

What gets collected by default
-------------------------------
• CMake files: CMakeLists.txt (all), CMakeCache.txt, CMakeOutput/Error.log
• Parser/CLI sources: src\cli\*.{c,cpp,h,hpp}
• Public headers: include\*.{h,hpp} (if present)
• Build files: compile_commands.json (if present), *.sln, *.vcxproj (top-level)
• Toolchain versions: cmake, cl/msvc, ninja (if present), git info
• Environment summary: PATH (trimmed), VS DevCmd if active (heuristics)
• Optional runtime: if -ExePath provided, runs HELP and captures console output

Notes
-----
• This script uses built-in Compress-Archive (no external deps).
• It is read-only for your source tree; it creates a staging folder under OutDir.
• You can re-run it safely; each run uses a new timestamped folder/zip.
• If you want to add logs (e.g., MSBuild /verbosity:detailed), just drop them
  anywhere under your repo and re-run with -IncludeGlobs to pick them up.

Troubleshooting
---------------
• If PowerShell execution policy blocks the script:
    Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
    .\make_parser_debug_zip.ps1 -Verbose
• If Compress-Archive fails due to long paths, try enabling long paths in
  Windows or shorten the RepoRoot temporarily.
